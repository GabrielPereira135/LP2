﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace volume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtRaio.Text = "";
            TxtAltura.Clear();
            TxtVolume.Text = string.Empty;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            Double R, H;

            if ((double.TryParse(TxtRaio.Text,
                out R) && double.TryParse(TxtAltura.Text,
                out H)))
            {
                double V = Math.PI * Math.Pow(R,
                    2) * H;
                TxtVolume.Text =
            V.ToString("N2");
            }
            else
                MessageBox.Show("Dados Inválidos");
        }
    }
}
