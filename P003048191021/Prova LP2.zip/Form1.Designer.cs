﻿namespace Fazer_a_prova
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexec = new System.Windows.Forms.Button();
            this.logvendas = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnexec
            // 
            this.btnexec.Location = new System.Drawing.Point(608, 135);
            this.btnexec.Name = "btnexec";
            this.btnexec.Size = new System.Drawing.Size(162, 127);
            this.btnexec.TabIndex = 0;
            this.btnexec.Text = "Executar";
            this.btnexec.UseVisualStyleBackColor = true;
            this.btnexec.Click += new System.EventHandler(this.button1_Click);
            // 
            // logvendas
            // 
            this.logvendas.FormattingEnabled = true;
            this.logvendas.Location = new System.Drawing.Point(83, 25);
            this.logvendas.Name = "logvendas";
            this.logvendas.Size = new System.Drawing.Size(260, 290);
            this.logvendas.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.logvendas);
            this.Controls.Add(this.btnexec);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnexec;
        private System.Windows.Forms.ListBox logvendas;
    }
}

