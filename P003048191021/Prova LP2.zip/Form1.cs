﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Fazer_a_prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ra, i, n, j;
            string t = " ";
            if (int.TryParse(Interaction.InputBox("Digite o último digito de seu RA"), out ra))
            {
                n = ra;
                if (ra == 0)
                {
                    n = 10;
                }
                double x, s = 0,vt = 0;
                double[,] vendas = new double[n, 4];
                double[] total = new double[n];
                for (i = 0; i < n; i++)
                {
                    logvendas.Items.Add("----------");
                    for (j = 0; j < 4; j++)
                    {
                        t = Interaction.InputBox("Coloque o valor da venda da semana " + (i + 1) + " e do mes " + (j + 1));
                        if (!double.TryParse(t, out x))
                        {
                            MessageBox.Show("Dado Inválido");
                            j--;
                        }
                        else
                        {
                            s = x + s;
                            vendas[i, j] = x;
                            logvendas.Items.Add("Total do mes " + (i + 1) + " Semana: " + (j + 1) + " R$" + x.ToString("N2"));
                        }
                    }
                    total[i] = s;
                    vt = total[i] + vt;
                    logvendas.Items.Add("Valor total do mes foi de R$" + total[i].ToString("N2"));
                    s = 0;
                }
                logvendas.Items.Add("----------");
                logvendas.Items.Add("O valor de vendas total foi de: R$" + vt.ToString("N2"));



            }
            else
            {
                MessageBox.Show("Dado inválido, entre com um número inteiro");
            }
        }
    }
}