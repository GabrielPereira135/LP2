﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc_INSS_IRRF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnVerificaDesconto_Click(object sender, EventArgs e)
        {
            int f;
            double sal,M,T,sl,R;
            if ((int.TryParse(TxtFilhos.Text,
                out f) && double.TryParse(TxtSalBruto.Text,
                out sal)))
            {
                if (RdnButtonMasc.Checked == true || RdnButtonFem.Checked == true)
                {
                    //Calculo INSS
                    if (sal <= 800.47)
                    {
                        TxtINSS.Text = "7,65%";
                        R = 0.0765 * sal;
                        TxtINSSdesc.Text =
                    R.ToString("N2");
                    }
                    if (sal > 800.47 && sal <= 1050)
                    {
                        TxtINSS.Text = "8,65%";
                        R = 0.0865 * sal;
                        TxtINSSdesc.Text =
                    R.ToString("N2");
                    }
                    if (sal > 1050 && sal <= 1400.77)
                    {
                        TxtINSS.Text = "9,00%";
                        R = 0.09 * sal;
                        TxtINSSdesc.Text =
                    R.ToString("N2");
                    }
                    if (sal > 1400.77 & sal <= 2801.56)
                    {
                        TxtINSS.Text = "11,00%";
                        R = 0.11 * sal;
                        TxtINSSdesc.Text =
                    R.ToString("N2");
                    }
                    if (sal > 2801.56)
                    {
                        TxtINSS.Text = "TETO";
                        R = 308.17;
                        TxtINSSdesc.Text =
                    R.ToString("N2");
                    }
                    //Calculo IRRF
                    if (sal <= 1257.12)
                    {
                        TxtIRRF.Text = "Isento";
                        M = 0;
                        TxtIRPFdesc.Text =
                    M.ToString("N2");
                    }
                    if (sal <= 2512.08 && sal > 1257.12)
                    {
                        TxtIRRF.Text = "15,00%";
                        M = 0.15 * sal;
                        TxtIRPFdesc.Text =
                    M.ToString("N2");
                    }
                    if (sal > 2512.08)
                    {
                        TxtIRRF.Text = "27,50%";
                        M = 0.275 * sal;
                        TxtIRPFdesc.Text =
                    M.ToString("N2");
                    }
                    if ((double.TryParse(TxtINSSdesc.Text,
                        out R) && double.TryParse(TxtIRPFdesc.Text,
                        out M)))
                    {
                        if (ChBoxCasado.Checked == true)
                        {
                            if (f > 0)
                            {
                                if (sal <= 435.53)
                                {
                                    T = f * 22.33;
                                    sl = sal - R - M + T;
                                    TxtFamilia.Text =
                                T.ToString("N2");
                                    TxtLiq.Text =
                                sl.ToString("N2");
                                }
                                if (sal <= 654.61)
                                {
                                    T = f * 15.74;
                                    TxtFamilia.Text =
                                T.ToString("N2");
                                    sl = sal - R - M + T;
                                    TxtLiq.Text =
                                sl.ToString("N2");
                                }
                                else
                                {
                                    T = f * 0;
                                    TxtFamilia.Text =
                                T.ToString("N2");
                                    sl = sal - R - M + T;
                                    TxtLiq.Text =
                                sl.ToString("N2");
                                }
                            }
                            else
                            {
                                T = 0;
                                TxtFamilia.Text =
                                T.ToString("N2");
                                sl = sal - R - M + T;
                                TxtLiq.Text =
                            sl.ToString("N2");
                            }
                        }
                        if (ChBoxCasado.Checked == false)
                        {
                            T = 0;
                            TxtFamilia.Text =
                                T.ToString("N2");
                            sl = sal - R - M + T;
                            TxtLiq.Text =
                        sl.ToString("N2");
                        }
                    }
                    //Verificação de situação
                    if (RdnButtonMasc.Checked == true && ChBoxCasado.Checked == true)
                    {
                        LblDados.Text = "Os descontos do salário do Sr. " + Txtnome.Text
                                        + " que é casado e tem " + TxtFilhos.Text + " filho(s) são: ";
                    }
                    if (RdnButtonMasc.Checked == true && ChBoxCasado.Checked == false)
                    {
                        LblDados.Text = "Os descontos do salário do Sr. " + Txtnome.Text
                                        + " que é solteiro e tem " + TxtFilhos.Text + " filho(s) são: ";
                    }
                    if (RdnButtonFem.Checked == true && ChBoxCasado.Checked == false)
                    {
                        LblDados.Text = "Os descontos do salário da Sra. " + Txtnome.Text
                                        + " que é solteira e tem " + TxtFilhos.Text + " filho(s) são: ";
                    }
                    if (RdnButtonFem.Checked == true && ChBoxCasado.Checked == true)
                    {
                        LblDados.Text = "Os descontos do salário da Sra. " + Txtnome.Text
                                        + " que é casada e tem " + TxtFilhos.Text + " filho(s) são: ";
                    }
                }
                else
                {
                    MessageBox.Show("Não selecionado o sexo do funcionário");
                }

            }
            else
            {
                MessageBox.Show("Dados incompletos ou inválidos");
            }
        }

        private void ChBoxCasado_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void LblDados_Click(object sender, EventArgs e)
        {

        }
    }
}
                

