﻿namespace Calc_INSS_IRRF
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lblnome = new System.Windows.Forms.Label();
            this.LblSalbruto = new System.Windows.Forms.Label();
            this.LblFilhos = new System.Windows.Forms.Label();
            this.LblINSS = new System.Windows.Forms.Label();
            this.LblIRRF = new System.Windows.Forms.Label();
            this.LblFam = new System.Windows.Forms.Label();
            this.LblDados = new System.Windows.Forms.Label();
            this.LblDescIRPF = new System.Windows.Forms.Label();
            this.LblDescINSS = new System.Windows.Forms.Label();
            this.LblLiq = new System.Windows.Forms.Label();
            this.Txtnome = new System.Windows.Forms.MaskedTextBox();
            this.TxtSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.TxtFilhos = new System.Windows.Forms.MaskedTextBox();
            this.TxtINSS = new System.Windows.Forms.MaskedTextBox();
            this.TxtIRRF = new System.Windows.Forms.MaskedTextBox();
            this.TxtFamilia = new System.Windows.Forms.MaskedTextBox();
            this.TxtLiq = new System.Windows.Forms.MaskedTextBox();
            this.TxtINSSdesc = new System.Windows.Forms.MaskedTextBox();
            this.TxtIRPFdesc = new System.Windows.Forms.MaskedTextBox();
            this.BtnVerificaDesconto = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.GrpSexo = new System.Windows.Forms.GroupBox();
            this.RdnButtonFem = new System.Windows.Forms.RadioButton();
            this.RdnButtonMasc = new System.Windows.Forms.RadioButton();
            this.ChBoxCasado = new System.Windows.Forms.CheckBox();
            this.GrpSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // Lblnome
            // 
            this.Lblnome.AutoSize = true;
            this.Lblnome.Location = new System.Drawing.Point(6, 25);
            this.Lblnome.Name = "Lblnome";
            this.Lblnome.Size = new System.Drawing.Size(105, 13);
            this.Lblnome.TabIndex = 0;
            this.Lblnome.Text = "Nome do funcionário";
            // 
            // LblSalbruto
            // 
            this.LblSalbruto.AutoSize = true;
            this.LblSalbruto.Location = new System.Drawing.Point(241, 32);
            this.LblSalbruto.Name = "LblSalbruto";
            this.LblSalbruto.Size = new System.Drawing.Size(66, 13);
            this.LblSalbruto.TabIndex = 1;
            this.LblSalbruto.Text = "Salário bruto";
            // 
            // LblFilhos
            // 
            this.LblFilhos.AutoSize = true;
            this.LblFilhos.Location = new System.Drawing.Point(6, 71);
            this.LblFilhos.Name = "LblFilhos";
            this.LblFilhos.Size = new System.Drawing.Size(61, 13);
            this.LblFilhos.TabIndex = 2;
            this.LblFilhos.Text = "N° de filhos";
            // 
            // LblINSS
            // 
            this.LblINSS.AutoSize = true;
            this.LblINSS.Location = new System.Drawing.Point(6, 185);
            this.LblINSS.Name = "LblINSS";
            this.LblINSS.Size = new System.Drawing.Size(73, 13);
            this.LblINSS.TabIndex = 3;
            this.LblINSS.Text = "Aliquota INSS";
            this.LblINSS.Click += new System.EventHandler(this.label4_Click);
            // 
            // LblIRRF
            // 
            this.LblIRRF.AutoSize = true;
            this.LblIRRF.Location = new System.Drawing.Point(6, 229);
            this.LblIRRF.Name = "LblIRRF";
            this.LblIRRF.Size = new System.Drawing.Size(72, 13);
            this.LblIRRF.TabIndex = 4;
            this.LblIRRF.Text = "Aliquota IRPF";
            // 
            // LblFam
            // 
            this.LblFam.AutoSize = true;
            this.LblFam.Location = new System.Drawing.Point(6, 265);
            this.LblFam.Name = "LblFam";
            this.LblFam.Size = new System.Drawing.Size(76, 13);
            this.LblFam.TabIndex = 5;
            this.LblFam.Text = "Salário Família";
            // 
            // LblDados
            // 
            this.LblDados.AutoSize = true;
            this.LblDados.Location = new System.Drawing.Point(6, 136);
            this.LblDados.Name = "LblDados";
            this.LblDados.Size = new System.Drawing.Size(52, 13);
            this.LblDados.TabIndex = 6;
            this.LblDados.Text = "LblDados";
            this.LblDados.Click += new System.EventHandler(this.LblDados_Click);
            // 
            // LblDescIRPF
            // 
            this.LblDescIRPF.AutoSize = true;
            this.LblDescIRPF.Location = new System.Drawing.Point(241, 264);
            this.LblDescIRPF.Name = "LblDescIRPF";
            this.LblDescIRPF.Size = new System.Drawing.Size(80, 13);
            this.LblDescIRPF.TabIndex = 7;
            this.LblDescIRPF.Text = "Desconto IRPF";
            // 
            // LblDescINSS
            // 
            this.LblDescINSS.AutoSize = true;
            this.LblDescINSS.Location = new System.Drawing.Point(240, 205);
            this.LblDescINSS.Name = "LblDescINSS";
            this.LblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.LblDescINSS.TabIndex = 8;
            this.LblDescINSS.Text = "Desconto INSS";
            // 
            // LblLiq
            // 
            this.LblLiq.AutoSize = true;
            this.LblLiq.Location = new System.Drawing.Point(6, 310);
            this.LblLiq.Name = "LblLiq";
            this.LblLiq.Size = new System.Drawing.Size(78, 13);
            this.LblLiq.TabIndex = 9;
            this.LblLiq.Text = "Salário Líquido";
            // 
            // Txtnome
            // 
            this.Txtnome.Location = new System.Drawing.Point(117, 22);
            this.Txtnome.Name = "Txtnome";
            this.Txtnome.Size = new System.Drawing.Size(100, 20);
            this.Txtnome.TabIndex = 10;
            // 
            // TxtSalBruto
            // 
            this.TxtSalBruto.Location = new System.Drawing.Point(382, 25);
            this.TxtSalBruto.Name = "TxtSalBruto";
            this.TxtSalBruto.Size = new System.Drawing.Size(100, 20);
            this.TxtSalBruto.TabIndex = 11;
            // 
            // TxtFilhos
            // 
            this.TxtFilhos.Location = new System.Drawing.Point(117, 64);
            this.TxtFilhos.Name = "TxtFilhos";
            this.TxtFilhos.Size = new System.Drawing.Size(100, 20);
            this.TxtFilhos.TabIndex = 12;
            // 
            // TxtINSS
            // 
            this.TxtINSS.Enabled = false;
            this.TxtINSS.Location = new System.Drawing.Point(117, 178);
            this.TxtINSS.Name = "TxtINSS";
            this.TxtINSS.Size = new System.Drawing.Size(100, 20);
            this.TxtINSS.TabIndex = 13;
            // 
            // TxtIRRF
            // 
            this.TxtIRRF.Enabled = false;
            this.TxtIRRF.Location = new System.Drawing.Point(117, 222);
            this.TxtIRRF.Name = "TxtIRRF";
            this.TxtIRRF.Size = new System.Drawing.Size(100, 20);
            this.TxtIRRF.TabIndex = 14;
            // 
            // TxtFamilia
            // 
            this.TxtFamilia.Enabled = false;
            this.TxtFamilia.Location = new System.Drawing.Point(117, 258);
            this.TxtFamilia.Name = "TxtFamilia";
            this.TxtFamilia.Size = new System.Drawing.Size(100, 20);
            this.TxtFamilia.TabIndex = 15;
            // 
            // TxtLiq
            // 
            this.TxtLiq.Enabled = false;
            this.TxtLiq.Location = new System.Drawing.Point(117, 303);
            this.TxtLiq.Name = "TxtLiq";
            this.TxtLiq.Size = new System.Drawing.Size(100, 20);
            this.TxtLiq.TabIndex = 16;
            // 
            // TxtINSSdesc
            // 
            this.TxtINSSdesc.Enabled = false;
            this.TxtINSSdesc.Location = new System.Drawing.Point(344, 198);
            this.TxtINSSdesc.Name = "TxtINSSdesc";
            this.TxtINSSdesc.Size = new System.Drawing.Size(100, 20);
            this.TxtINSSdesc.TabIndex = 17;
            // 
            // TxtIRPFdesc
            // 
            this.TxtIRPFdesc.Enabled = false;
            this.TxtIRPFdesc.Location = new System.Drawing.Point(344, 257);
            this.TxtIRPFdesc.Name = "TxtIRPFdesc";
            this.TxtIRPFdesc.Size = new System.Drawing.Size(100, 20);
            this.TxtIRPFdesc.TabIndex = 18;
            // 
            // BtnVerificaDesconto
            // 
            this.BtnVerificaDesconto.Location = new System.Drawing.Point(558, 12);
            this.BtnVerificaDesconto.Name = "BtnVerificaDesconto";
            this.BtnVerificaDesconto.Size = new System.Drawing.Size(146, 59);
            this.BtnVerificaDesconto.TabIndex = 19;
            this.BtnVerificaDesconto.Text = "Verifica desconto";
            this.BtnVerificaDesconto.UseVisualStyleBackColor = true;
            this.BtnVerificaDesconto.Click += new System.EventHandler(this.BtnVerificaDesconto_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(612, 200);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 21;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.button3_Click);
            // 
            // GrpSexo
            // 
            this.GrpSexo.Controls.Add(this.RdnButtonFem);
            this.GrpSexo.Controls.Add(this.RdnButtonMasc);
            this.GrpSexo.Location = new System.Drawing.Point(504, 90);
            this.GrpSexo.Name = "GrpSexo";
            this.GrpSexo.Size = new System.Drawing.Size(200, 68);
            this.GrpSexo.TabIndex = 22;
            this.GrpSexo.TabStop = false;
            this.GrpSexo.Text = "Sexo";
            // 
            // RdnButtonFem
            // 
            this.RdnButtonFem.AutoSize = true;
            this.RdnButtonFem.Location = new System.Drawing.Point(23, 42);
            this.RdnButtonFem.Name = "RdnButtonFem";
            this.RdnButtonFem.Size = new System.Drawing.Size(67, 17);
            this.RdnButtonFem.TabIndex = 1;
            this.RdnButtonFem.TabStop = true;
            this.RdnButtonFem.Text = "Feminino";
            this.RdnButtonFem.UseVisualStyleBackColor = true;
            // 
            // RdnButtonMasc
            // 
            this.RdnButtonMasc.AutoSize = true;
            this.RdnButtonMasc.Location = new System.Drawing.Point(23, 19);
            this.RdnButtonMasc.Name = "RdnButtonMasc";
            this.RdnButtonMasc.Size = new System.Drawing.Size(73, 17);
            this.RdnButtonMasc.TabIndex = 0;
            this.RdnButtonMasc.TabStop = true;
            this.RdnButtonMasc.Text = "Masculino";
            this.RdnButtonMasc.UseVisualStyleBackColor = true;
            // 
            // ChBoxCasado
            // 
            this.ChBoxCasado.AutoSize = true;
            this.ChBoxCasado.Location = new System.Drawing.Point(504, 164);
            this.ChBoxCasado.Name = "ChBoxCasado";
            this.ChBoxCasado.Size = new System.Drawing.Size(62, 17);
            this.ChBoxCasado.TabIndex = 23;
            this.ChBoxCasado.Text = "Casado";
            this.ChBoxCasado.UseVisualStyleBackColor = true;
            this.ChBoxCasado.CheckedChanged += new System.EventHandler(this.ChBoxCasado_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ChBoxCasado);
            this.Controls.Add(this.GrpSexo);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnVerificaDesconto);
            this.Controls.Add(this.TxtIRPFdesc);
            this.Controls.Add(this.TxtINSSdesc);
            this.Controls.Add(this.TxtLiq);
            this.Controls.Add(this.TxtFamilia);
            this.Controls.Add(this.TxtIRRF);
            this.Controls.Add(this.TxtINSS);
            this.Controls.Add(this.TxtFilhos);
            this.Controls.Add(this.TxtSalBruto);
            this.Controls.Add(this.Txtnome);
            this.Controls.Add(this.LblLiq);
            this.Controls.Add(this.LblDescINSS);
            this.Controls.Add(this.LblDescIRPF);
            this.Controls.Add(this.LblDados);
            this.Controls.Add(this.LblFam);
            this.Controls.Add(this.LblIRRF);
            this.Controls.Add(this.LblINSS);
            this.Controls.Add(this.LblFilhos);
            this.Controls.Add(this.LblSalbruto);
            this.Controls.Add(this.Lblnome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.GrpSexo.ResumeLayout(false);
            this.GrpSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lblnome;
        private System.Windows.Forms.Label LblSalbruto;
        private System.Windows.Forms.Label LblFilhos;
        private System.Windows.Forms.Label LblINSS;
        private System.Windows.Forms.Label LblIRRF;
        private System.Windows.Forms.Label LblFam;
        private System.Windows.Forms.Label LblDados;
        private System.Windows.Forms.Label LblDescIRPF;
        private System.Windows.Forms.Label LblDescINSS;
        private System.Windows.Forms.Label LblLiq;
        private System.Windows.Forms.MaskedTextBox Txtnome;
        private System.Windows.Forms.MaskedTextBox TxtSalBruto;
        private System.Windows.Forms.MaskedTextBox TxtFilhos;
        private System.Windows.Forms.MaskedTextBox TxtINSS;
        private System.Windows.Forms.MaskedTextBox TxtIRRF;
        private System.Windows.Forms.MaskedTextBox TxtFamilia;
        private System.Windows.Forms.MaskedTextBox TxtLiq;
        private System.Windows.Forms.MaskedTextBox TxtINSSdesc;
        private System.Windows.Forms.MaskedTextBox TxtIRPFdesc;
        private System.Windows.Forms.Button BtnVerificaDesconto;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.GroupBox GrpSexo;
        private System.Windows.Forms.RadioButton RdnButtonFem;
        private System.Windows.Forms.RadioButton RdnButtonMasc;
        private System.Windows.Forms.CheckBox ChBoxCasado;
    }
}

