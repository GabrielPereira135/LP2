﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Atividade_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            for(x = 0;x < 20;x++)
            {
                valor = Interaction.InputBox("Digite o dado" + (x + 1),
                    "Entrada de dados");
                if(int.TryParse(valor,out vetor[x]))
                
                    auxiliar = vetor[x].ToString() + "\n" + auxiliar;
                
                else
                {
                    MessageBox.Show("Dado inválido");
                    x--;
                }

            }
            MessageBox.Show(auxiliar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            for (x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o dado da posição" + (x + 1),
                    "Digitação dos dados");
                if (!int.TryParse(valor, out vetor[x]))
                {
                    MessageBox.Show("Número inválido");
                    x--;
                }
            }
            Array.Reverse(vetor);
            for (x = 0; x <20; x++)
                auxiliar += vetor[x] + "\n";

                MessageBox.Show(auxiliar);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double [] preço = new double[10];
            int[] qtd = new int[10];
            double auxt;
            int i;
            string aux = "", aux2 = "", valorp = "", valorq = "";
            for(i = 0; i < 10;i++)
            {
                valorp = Interaction.InputBox("Entrada de preços " + (i + 1),
                    "Digite o preço");
                if (double.TryParse(valorp, out preço[i]))
                    aux = preço[i].ToString() + "\n";
                else
                {
                    MessageBox.Show("Digite um preço válido");
                    i--;
                }
            }
            for (i = 0; i < 10; i++)
            {
                valorq = Interaction.InputBox("Entrada de quantidades " + (i + 1),
                    "Digite a quantidade vendida");
                if (int.TryParse(valorq, out qtd[i]))
                    aux2 = qtd[i].ToString() + "\n";
                else
                {
                    MessageBox.Show("Digite uma quantidade válida");
                    i--;
                }
            }
            double s = 0;
            for(i = 0; i < 10;i++)
            {
                auxt = qtd[i] * preço[i];
                s = s + auxt;
            }
            MessageBox.Show("O faturamento foi de R$ " + s);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Int32 i, total = 0;
            string[] alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Neuma", "Tobby" };
            Int32 n = alunos.Length;
            for(i = 0; i < n - 1; i++)
            {
                total += alunos[i].Length;
            }
            MessageBox.Show("O total foi de " + total);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fátima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thiago");
            nomes.RemoveAt(6);
            string s = "";
            foreach(string i in nomes)
            {
                s = s + i + "\n";
            }
            MessageBox.Show(s);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] medias = new double[20];
            string vm = "",aux = "",aux2 = "";
            for(int i = 0; i < 20;i++)
            {
                for(int j = 0; j < 3;j++)
                {
                     vm = Interaction.InputBox("Digite as notas do aluno "+(i + 1),
                        "Nota " + (j + 1));
                    if (double.TryParse(vm, out notas[i, j]) && (notas[i,j] >=0 && notas[i,j] <=10))
                        {
                        aux = notas[i, j].ToString() + "\n";
                    }
                    else
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    }
                }
            for(int i = 0; i < 20;i++)
            {
                double s = 0;
                for(int j = 0; j < 3;j++)
                {
                    s = s + notas[i, j];
                    if(j == 2)
                    {
                        medias[i] = s / 3;
                    }
                }
            }
            for (int i = 0; i < 20; i++)
            {
                aux2 = medias[i].ToString() + "\n";
                MessageBox.Show("A media do aluno " + (i + 1) + " foi de " + aux2);
            }
            
        }

        private void exercício7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EX_7 frm7 = new EX_7();
            frm7.MdiParent = this;
            frm7.WindowState = FormWindowState.Maximized;
            frm7.Show();
}

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Int64 ra, num;
            int i, aux = 0;
            ArrayList lista = new ArrayList();
            string s;
            Int64.TryParse(Interaction.
                InputBox("Digite o último dígito de seu RA"), out ra);
            num = ra;
            if (ra == 0)
            {
                num = 10;
            }
            for (i = 0; i < num; i++)
            {
                s = Interaction.InputBox("Coloque o " + (i + 1) + " nome:");
                lista.Add(s);
            }
            foreach(string ch in lista)
            {
                foreach(char x in ch)
                {
                    if(!Char.IsWhiteSpace(x))
                    {
                        aux++;
                    }
                }
                MessageBox.Show( "\n O nome " + ch + " tem "
                    + aux + " caracteres.");
            }
        }
    }
    }
