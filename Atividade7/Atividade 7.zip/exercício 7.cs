﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_7
{
    public partial class Exercício_7 : Form
    {
        public Exercício_7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i;
            int soma = 0;
            string s = "";
            for(i = 0; i < 1;i++)
            {
                s = Interaction.InputBox("Coloque o nome da pessoa");
            }
            foreach(char c in s)
            {
                if(c != ' ')
                     soma++;
            }
            listBox1.Text = "nome " + s + "tem" + soma + "caracteres";
            

        }
    }
}
