﻿namespace Triangulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblA = new System.Windows.Forms.Label();
            this.LblB = new System.Windows.Forms.Label();
            this.LblC = new System.Windows.Forms.Label();
            this.TxtLa = new System.Windows.Forms.TextBox();
            this.TxtLb = new System.Windows.Forms.TextBox();
            this.TxtLc = new System.Windows.Forms.TextBox();
            this.BtnTipo = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblA
            // 
            this.LblA.AutoSize = true;
            this.LblA.Location = new System.Drawing.Point(110, 43);
            this.LblA.Name = "LblA";
            this.LblA.Size = new System.Drawing.Size(41, 13);
            this.LblA.TabIndex = 0;
            this.LblA.Text = "Lado A";
            // 
            // LblB
            // 
            this.LblB.AutoSize = true;
            this.LblB.Location = new System.Drawing.Point(110, 93);
            this.LblB.Name = "LblB";
            this.LblB.Size = new System.Drawing.Size(41, 13);
            this.LblB.TabIndex = 1;
            this.LblB.Text = "Lado B";
            // 
            // LblC
            // 
            this.LblC.AutoSize = true;
            this.LblC.Location = new System.Drawing.Point(110, 162);
            this.LblC.Name = "LblC";
            this.LblC.Size = new System.Drawing.Size(41, 13);
            this.LblC.TabIndex = 2;
            this.LblC.Text = "Lado C";
            // 
            // TxtLa
            // 
            this.TxtLa.Location = new System.Drawing.Point(242, 36);
            this.TxtLa.Name = "TxtLa";
            this.TxtLa.Size = new System.Drawing.Size(100, 20);
            this.TxtLa.TabIndex = 3;
            // 
            // TxtLb
            // 
            this.TxtLb.Location = new System.Drawing.Point(242, 90);
            this.TxtLb.Name = "TxtLb";
            this.TxtLb.Size = new System.Drawing.Size(100, 20);
            this.TxtLb.TabIndex = 4;
            // 
            // TxtLc
            // 
            this.TxtLc.Location = new System.Drawing.Point(241, 155);
            this.TxtLc.Name = "TxtLc";
            this.TxtLc.Size = new System.Drawing.Size(100, 20);
            this.TxtLc.TabIndex = 5;
            // 
            // BtnTipo
            // 
            this.BtnTipo.Location = new System.Drawing.Point(113, 233);
            this.BtnTipo.Name = "BtnTipo";
            this.BtnTipo.Size = new System.Drawing.Size(75, 23);
            this.BtnTipo.TabIndex = 6;
            this.BtnTipo.Text = "Verificar tipo";
            this.BtnTipo.UseVisualStyleBackColor = true;
            this.BtnTipo.Click += new System.EventHandler(this.BtnTipo_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(266, 232);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(75, 23);
            this.BtnLimpar.TabIndex = 7;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(454, 231);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 8;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnTipo);
            this.Controls.Add(this.TxtLc);
            this.Controls.Add(this.TxtLb);
            this.Controls.Add(this.TxtLa);
            this.Controls.Add(this.LblC);
            this.Controls.Add(this.LblB);
            this.Controls.Add(this.LblA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblA;
        private System.Windows.Forms.Label LblB;
        private System.Windows.Forms.Label LblC;
        private System.Windows.Forms.TextBox TxtLa;
        private System.Windows.Forms.TextBox TxtLb;
        private System.Windows.Forms.TextBox TxtLc;
        private System.Windows.Forms.Button BtnTipo;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
    }
}

