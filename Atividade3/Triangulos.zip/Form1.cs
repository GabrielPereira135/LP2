﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtLa.Text = "";
            TxtLb.Clear();
            TxtLc.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnTipo_Click(object sender, EventArgs e)
        {
            Double A, B, C;

            if ((double.TryParse(TxtLa.Text,
                out A) && double.TryParse(TxtLb.Text,
                out B) && double.TryParse(TxtLc.Text,
                out C)))
            {
                if (A > 0 && B > 0 && C > 0)
                {

                    if (A == B && B == C && C == A)
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }
                    if ((A == B && A != C && B != C) || (A == C && A != B && B != C) || (C == B && C != A && B != A))
                    {
                        MessageBox.Show("Triângulo Isósceles");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo Escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("Um dos lados do triângulo é negativo ou igual a zero, logo, inválido");
                }
            }
            else
            {
                MessageBox.Show("Dados Inválidos");
            }

        }
    }
}
