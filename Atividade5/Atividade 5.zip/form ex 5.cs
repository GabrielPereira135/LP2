﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ppppp
{
    public partial class form_ex_5 : Form
    {
        public form_ex_5()
        {
            InitializeComponent();
        }
    }
}
