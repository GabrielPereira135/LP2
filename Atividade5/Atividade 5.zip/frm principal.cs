﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ppppp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Teclou Ctrl + c");
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form_ex_2 frm2 = new form_ex_2();
            frm2.MdiParent = this;
            frm2.WindowState = FormWindowState.Maximized; 
            frm2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form_ex_3 frm3 = new form_ex_3();
            frm3.MdiParent = this;
            frm3.WindowState = FormWindowState.Maximized;
            frm3.Show();
        }
    }
}
