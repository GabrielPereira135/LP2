﻿namespace ppppp
{
    partial class form_ex_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btninserir1 = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.btninserir3 = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(185, 38);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra1.TabIndex = 0;
            this.txtpalavra1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(185, 86);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra2.TabIndex = 1;
            // 
            // btninserir1
            // 
            this.btninserir1.Location = new System.Drawing.Point(102, 205);
            this.btninserir1.Name = "btninserir1";
            this.btninserir1.Size = new System.Drawing.Size(75, 73);
            this.btninserir1.TabIndex = 2;
            this.btninserir1.Text = "TESTAR IGUAIS";
            this.btninserir1.UseVisualStyleBackColor = true;
            this.btninserir1.Click += new System.EventHandler(this.btninserir1_Click);
            // 
            // btninserir2
            // 
            this.btninserir2.Location = new System.Drawing.Point(283, 205);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(75, 73);
            this.btninserir2.TabIndex = 3;
            this.btninserir2.Text = "INSERIR TEXTO 1 NO TEXTO 2";
            this.btninserir2.UseVisualStyleBackColor = true;
            this.btninserir2.Click += new System.EventHandler(this.btninserir2_Click);
            // 
            // btninserir3
            // 
            this.btninserir3.Location = new System.Drawing.Point(470, 205);
            this.btninserir3.Name = "btninserir3";
            this.btninserir3.Size = new System.Drawing.Size(116, 73);
            this.btninserir3.TabIndex = 4;
            this.btninserir3.Text = "INSERIR ASTERISCOS NO TEXTO 1";
            this.btninserir3.UseVisualStyleBackColor = true;
            this.btninserir3.Click += new System.EventHandler(this.btninserir3_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(60, 45);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(52, 13);
            this.label.TabIndex = 5;
            this.label.Text = "Palavra 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Palavra 2";
            // 
            // form_ex_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label);
            this.Controls.Add(this.btninserir3);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Name = "form_ex_2";
            this.Text = "form_ex_2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btninserir1;
        private System.Windows.Forms.Button btninserir2;
        private System.Windows.Forms.Button btninserir3;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label2;
    }
}