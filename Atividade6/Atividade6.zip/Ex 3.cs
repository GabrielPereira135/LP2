﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6
{
    public partial class Ex_3 : Form
    {
        public Ex_3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s,so;
            int d;
            s = txtpalavra.Text;
            d = s.Length;
            if (d <= 50)
            {
                so = s;
                char[] arr = s.ToCharArray();
                s = "";
                foreach (char c in arr)
                {
                    if (c != ' ')
                        s += c;
                }
                string s2 = s;
                Array.Reverse(arr);
                s2 = "";
                foreach (char ch in arr)
                {
                    if (ch != ' ')
                        s2 = s2 + ch.ToString();
                }
                if (String.Equals(s, s2, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("A palavra ou frase " + so.ToUpper() + " é palíndromo");
                }
                if (String.Compare(s, s2) != 0)
                {
                    MessageBox.Show("Não é palíndromo");
                }
            }
            else
            {
                MessageBox.Show("Frase ou palavra muito grande para ser testada");
            }
        }
    }
}
