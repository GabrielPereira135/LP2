﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6
{
    public partial class Ex_4 : Form
    {
        public Ex_4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double salb, sal, gt,cb,cc,cd,ct;
            double b = 0, c = 0, d = 0,p;
            int n;
            if ((double.TryParse(txtprod.Text,
                out p) & (double.TryParse(txtgrat.Text,
                out gt) & (double.TryParse(txtsal.Text,
                out sal) & (int.TryParse(txtnum.Text,
                out n))))))
            {
                if(p >= 100)
                {
                    b = 1;
                    if(p >= 150)
                    {
                        c = 1; d = 1;
                    }
                    if(p >=120 & p < 150)
                    {
                        c = 1;
                    }
                }
                cb = b * 0.05;
                cc = c * 0.1;
                cd = d * 1;
                ct = cc + cb + cd;
                salb = sal + sal * ct;
                salb = salb + gt;
                if(sal > 7000)
                {
                    if(gt > 0 & p >= 150)
                    {
                        MessageBox.Show("O salário bruto calculado foi de " + salb);
                    }
                    else
                    {
                        MessageBox.Show("Salário bruto de R$7000,00");
                    }
                }
                else
                {
                    MessageBox.Show("Salário bruto calculado foi de R$" + salb);
                }
}
            else
            {
                MessageBox.Show("Alguns itens para o cálculo tem que ser dados em forma de números,são esses " +
                    ":Salário,Gratificações,Nº de inscrição,Produção.");
            }
        }
    }
}
