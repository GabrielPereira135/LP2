﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6
{
    public partial class Ex_1 : Form
    {
        public Ex_1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s;
            int f = 0;
            s = rchtxt1.Text;
            char[] arr = s.ToCharArray();
            foreach(char c in rchtxt1.Text)
            {
                if(c == 'R' | c == 'r')
                {
                    f++;
                }
            }
            MessageBox.Show("O número de 'R's é igual a " + f);
            }

        private void button1_Click(object sender, EventArgs e)
        {
            string s;
            s = rchtxt1.Text;
            int i,p = 0;
            for(i = 0; i < rchtxt1.Text.Length;i++)
            {
                if(char.IsWhiteSpace(s,i))
                {
                    p++;
                }
            }
            MessageBox.Show("O número de espaços em branco é " + p);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int s = 0;
            int x = 0;
            string l = "";
            for(s = 0; s <= rchtxt1.Text.Length - 1;s++)
            {
                if((rchtxt1.Text.Substring(s,1) != "") && (rchtxt1.Text.Substring(s,1) == l))
                {
                    x++;
                }
                l = rchtxt1.Text.Substring(s, 1);
            }
            MessageBox.Show("O número de pares de letras é " + x);

        }
    }
}
