﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6
{
    public partial class Ex_2 : Form
    {
        public Ex_2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x;
            double s = 0,i;
            if((int.TryParse(txth.Text,
                out x)))
            {
                for(i = 1; i <= x;i++)
                {
                    s = s + (1 / i);
                }
                MessageBox.Show("O resultado é " + s);
            }
            else
            {
                MessageBox.Show("Entre com um número inteiro");
            }




        }
    }
}
