﻿namespace CalcPeso
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblH = new System.Windows.Forms.Label();
            this.LblP = new System.Windows.Forms.Label();
            this.LblPc = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.MskTxtH = new System.Windows.Forms.MaskedTextBox();
            this.MskTxtBoxP = new System.Windows.Forms.MaskedTextBox();
            this.MskTxtPc = new System.Windows.Forms.MaskedTextBox();
            this.GrpBoxSexo = new System.Windows.Forms.GroupBox();
            this.RdBtnFem = new System.Windows.Forms.RadioButton();
            this.RdbtnMasc = new System.Windows.Forms.RadioButton();
            this.BtnCalc = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.GrpBoxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblH
            // 
            this.LblH.AutoSize = true;
            this.LblH.Location = new System.Drawing.Point(130, 43);
            this.LblH.Name = "LblH";
            this.LblH.Size = new System.Drawing.Size(34, 13);
            this.LblH.TabIndex = 0;
            this.LblH.Text = "Altura";
            // 
            // LblP
            // 
            this.LblP.AutoSize = true;
            this.LblP.Location = new System.Drawing.Point(130, 99);
            this.LblP.Name = "LblP";
            this.LblP.Size = new System.Drawing.Size(57, 13);
            this.LblP.TabIndex = 1;
            this.LblP.Text = "Peso atual";
            // 
            // LblPc
            // 
            this.LblPc.AutoSize = true;
            this.LblPc.Location = new System.Drawing.Point(130, 155);
            this.LblPc.Name = "LblPc";
            this.LblPc.Size = new System.Drawing.Size(57, 13);
            this.LblPc.TabIndex = 2;
            this.LblPc.Text = "Peso Ideal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(130, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 3;
            // 
            // MskTxtH
            // 
            this.MskTxtH.Location = new System.Drawing.Point(219, 40);
            this.MskTxtH.Name = "MskTxtH";
            this.MskTxtH.Size = new System.Drawing.Size(100, 20);
            this.MskTxtH.TabIndex = 4;
            // 
            // MskTxtBoxP
            // 
            this.MskTxtBoxP.Location = new System.Drawing.Point(219, 96);
            this.MskTxtBoxP.Name = "MskTxtBoxP";
            this.MskTxtBoxP.Size = new System.Drawing.Size(100, 20);
            this.MskTxtBoxP.TabIndex = 5;
            // 
            // MskTxtPc
            // 
            this.MskTxtPc.Enabled = false;
            this.MskTxtPc.Location = new System.Drawing.Point(219, 152);
            this.MskTxtPc.Name = "MskTxtPc";
            this.MskTxtPc.Size = new System.Drawing.Size(100, 20);
            this.MskTxtPc.TabIndex = 6;
            // 
            // GrpBoxSexo
            // 
            this.GrpBoxSexo.Controls.Add(this.RdBtnFem);
            this.GrpBoxSexo.Controls.Add(this.RdbtnMasc);
            this.GrpBoxSexo.Location = new System.Drawing.Point(482, 40);
            this.GrpBoxSexo.Name = "GrpBoxSexo";
            this.GrpBoxSexo.Size = new System.Drawing.Size(200, 165);
            this.GrpBoxSexo.TabIndex = 8;
            this.GrpBoxSexo.TabStop = false;
            this.GrpBoxSexo.Text = "Sexo";
            // 
            // RdBtnFem
            // 
            this.RdBtnFem.AutoSize = true;
            this.RdBtnFem.Location = new System.Drawing.Point(19, 125);
            this.RdBtnFem.Name = "RdBtnFem";
            this.RdBtnFem.Size = new System.Drawing.Size(67, 17);
            this.RdBtnFem.TabIndex = 1;
            this.RdBtnFem.TabStop = true;
            this.RdBtnFem.Text = "Feminino";
            this.RdBtnFem.UseVisualStyleBackColor = true;
            // 
            // RdbtnMasc
            // 
            this.RdbtnMasc.AutoSize = true;
            this.RdbtnMasc.Location = new System.Drawing.Point(19, 32);
            this.RdbtnMasc.Name = "RdbtnMasc";
            this.RdbtnMasc.Size = new System.Drawing.Size(73, 17);
            this.RdbtnMasc.TabIndex = 0;
            this.RdbtnMasc.TabStop = true;
            this.RdbtnMasc.Text = "Masculino";
            this.RdbtnMasc.UseVisualStyleBackColor = true;
            // 
            // BtnCalc
            // 
            this.BtnCalc.Location = new System.Drawing.Point(72, 230);
            this.BtnCalc.Name = "BtnCalc";
            this.BtnCalc.Size = new System.Drawing.Size(159, 107);
            this.BtnCalc.TabIndex = 10;
            this.BtnCalc.Text = "Calcular e mostrar situação";
            this.BtnCalc.UseVisualStyleBackColor = true;
            this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(510, 305);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(75, 23);
            this.BtnLimpar.TabIndex = 11;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.button3_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(661, 305);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 12;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnCalc);
            this.Controls.Add(this.GrpBoxSexo);
            this.Controls.Add(this.MskTxtPc);
            this.Controls.Add(this.MskTxtBoxP);
            this.Controls.Add(this.MskTxtH);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LblPc);
            this.Controls.Add(this.LblP);
            this.Controls.Add(this.LblH);
            this.Name = "Form1";
            this.Text = "Form1";
            this.GrpBoxSexo.ResumeLayout(false);
            this.GrpBoxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblH;
        private System.Windows.Forms.Label LblP;
        private System.Windows.Forms.Label LblPc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox MskTxtH;
        private System.Windows.Forms.MaskedTextBox MskTxtBoxP;
        private System.Windows.Forms.MaskedTextBox MskTxtPc;
        private System.Windows.Forms.GroupBox GrpBoxSexo;
        private System.Windows.Forms.RadioButton RdBtnFem;
        private System.Windows.Forms.RadioButton RdbtnMasc;
        private System.Windows.Forms.Button BtnCalc;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
    }
}

