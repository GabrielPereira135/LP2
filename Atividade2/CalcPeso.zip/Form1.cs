﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcPeso
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox4_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MskTxtBoxP.Text = "";
            MskTxtH.Text = "";
            MskTxtPc.Text = "";
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            double H, P, Pc;
            if ((double.TryParse(MskTxtH.Text,
                out H) && double.TryParse(MskTxtBoxP.Text,
                out P)))
            {
                if (H > 0 && P > 0)
                {
                    if (RdbtnMasc.Checked == true)
                    {
                        Pc = ((72.7 * H)
                            - 58);
                        MskTxtPc.Text =
                            Pc.ToString("N2");
                    }
                    if (RdBtnFem.Checked == true)
                    {
                        Pc = ((62.1 * H)
                            - 44.7);
                        MskTxtPc.Text =
                            Pc.ToString("N2");
                    }
                    if ((double.TryParse(MskTxtPc.Text,
                        out Pc)))
                    {
                        if (Pc < P)
                        {
                            MessageBox.Show("Regime Obrigatório Já");
                        }
                        if (Pc == P)
                        {
                            MessageBox.Show("Você está com o peso ideal");
                        }
                        if (Pc > P)
                        {
                            MessageBox.Show("Coma bastante massas e doces");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Valor de peso e altura não podem ser iguais ou menores que zero");
                }
            }
            else
            {
                MessageBox.Show("Dados Inválidos ou incompletos");
            }
        }
    }
}
